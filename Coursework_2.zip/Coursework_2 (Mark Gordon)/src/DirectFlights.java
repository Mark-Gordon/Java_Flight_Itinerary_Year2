import java.util.Arrays;
import java.util.Set;

import javax.swing.text.html.HTMLDocument.Iterator;

import org.jgrapht.alg.DijkstraShortestPath;
import org.jgrapht.graph.DefaultWeightedEdge;
import org.jgrapht.graph.SimpleDirectedWeightedGraph;

public class DirectFlights {
	
	//all the airport vertexes
	private static String[] vertexes = {"Edinburgh", "Heathrow", "Dubai", "Sydney", "Kuala Lumpur", "Frankfurt", "Auckland", "Rio de Janeiro",
			"New York", "Santiago"};
	
	static DefaultWeightedEdge[] edges = new DefaultWeightedEdge[20];
	
	public static void main(String[] args){
		
		UserInteraction interact = new UserInteraction();
		
		
		SimpleDirectedWeightedGraph<String, DefaultWeightedEdge> flightsGraph = createWeightedGraph(vertexes);
		
		//prints flight information
		interact.printFlights(flightsGraph);
		
		System.out.println();
		
		//gets users start and destination airport
		String[] airports = interact.getUserInput();
		
		
		//finds the path
		findFlightPath(flightsGraph, airports[0], airports[1]);
		

		
	}
	
	public static SimpleDirectedWeightedGraph<String, DefaultWeightedEdge> createWeightedGraph(String[] vertexes){
		
		SimpleDirectedWeightedGraph<String, DefaultWeightedEdge> flightsGraph = new SimpleDirectedWeightedGraph<>(DefaultWeightedEdge.class);
		
		
		//holds the costs
		double[] costs = {80.00, 130.00, 570.00, 170.00, 190.00, 150.00, 90.00, 120.00, 430.00, 320.00};
		
		//used to connect vertexes, 0 (index 0) and 1 (index 1) are connected then 1 (index 1) and 0 (index 0) 
		//and then 1 (index 2) and 2 (index 3)and then 2 (index 3) and 1 (index 2) etc...
		//again quite a hacky method and better will exist
		int[] vertexindex = {0, 1, 1, 2, 1, 3, 2, 4, 2, 0, 4, 3, 0, 5,3, 6, 7, 8, 8, 9};	
		
       //adds vertexes to graph
		for(int i=0; i < vertexes.length; i++){
			
			flightsGraph.addVertex(vertexes[i]);
		}
		
		//adds edges and sets weight
		for(int i=0; i < edges.length; i+=2){
			
			
			edges[i] = flightsGraph.addEdge(vertexes[vertexindex[i]], vertexes[vertexindex[i+1]]);
			edges[i+1] = flightsGraph.addEdge(vertexes[vertexindex[i+1]], vertexes[vertexindex[i]]);
			
			flightsGraph.setEdgeWeight(edges[i], costs[i/2]);
        	flightsGraph.setEdgeWeight(edges[i+1], costs[i/2]);
			
		}
        
        return flightsGraph;
    }
	
	
	private static void findFlightPath(SimpleDirectedWeightedGraph<String, DefaultWeightedEdge> flightsGraph, String start, String end){
		
		UserInteraction interact = new UserInteraction();
		DijkstraShortestPath<String, DefaultWeightedEdge> path = new DijkstraShortestPath<String, DefaultWeightedEdge>(flightsGraph, start, end);
		
		//asks user for new input if the path doesn't exist.
		while(DijkstraShortestPath.findPathBetween(flightsGraph, start, end) == null){
			System.out.println("No route exists. Please try again.");
			String[] startAndEnd = interact.getUserInput();
			start = startAndEnd[0];
			end = startAndEnd[1];
			
			path = new DijkstraShortestPath<String, DefaultWeightedEdge>(flightsGraph, start, end);
		
		}
			
			//prints all the flight information
			System.out.println("Cheapest flight path is : ");
			
			java.util.Iterator<DefaultWeightedEdge> it = DijkstraShortestPath.findPathBetween(flightsGraph, start, end).iterator();
			
			int index = 1;
			
			while(it.hasNext()){
				String flight = it.next().toString();
				flight = flight.replace(":", " --> ");
						
				System.out.println(index + ". " + flight);
				index++;
			}
		
			
			System.out.println("Cost of cheapest flight path is : " + "£" + path.getPath().getWeight());
			
			
			
		
			
		
	}
	
	public String[] getVertexes(){
		
		return vertexes;
	}

}
