package ImprovedFlights;

import java.sql.Date;
import java.text.SimpleDateFormat;

public class Airport {
	
	private String startAirport;
	private String startTime;
	private String flightNo;
	private String endAirport;
	private String endTime;
	private double cost;
	
	
	public Airport(String sAir, String sTime, String fNo, String eAir, String eTime, int money){
		
		startAirport = sAir;
		startTime = sTime;
		flightNo = fNo;
		endAirport = eAir;
		endTime = eTime;
		cost = money;
		
	}
	
	public void setStartAirport(String start){
		startAirport = start;
	}
	
	public String getStartAirport(){
		return startAirport;
	}
	
	public void setStartTime(String sTime){
		startTime = sTime;
	}
	
	public String getStartTime(){
		return startTime;
	}
	
	public void setFlightNo(String flightNumber){
		flightNo = flightNumber;
	}
	
	public String getFlightNo(){
		return flightNo;
	}
	
	public void getEndAirport(String end){
		endAirport = end;
	}
	
	public String getEndAirport(){
		return endAirport;
	}
	
	
	
	public void setEndTime(String eTime){
		endTime = eTime;
	}
	
	public String getEndTime(){
		return endTime;
	}
	
	public void setCost(int money){	
		cost = money;
	}
	
	public double getCost(){	
		return cost;
	}
	
	public String toString(){
		return String.format("%-15s %-4s %-6s %-15s %-6s £%.2f\n", getStartAirport(), getStartTime(), getFlightNo(), getEndAirport(), getEndTime(), getCost());
		
	}
	

	

}