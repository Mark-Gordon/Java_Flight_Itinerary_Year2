package ImprovedFlights;

import java.util.ArrayList;

import java.util.HashMap;

import org.jgrapht.alg.DijkstraShortestPath;
import org.jgrapht.graph.DefaultWeightedEdge;
import org.jgrapht.graph.SimpleDirectedWeightedGraph;

public class DirectFlights2 {
	
	private static int timeInAir = 0;
	private static int totalTime = 0;
	public static final int TWENTYFOURHOURSINMINS = 1440;
	
	//holds all the airports
	private static Airport[][] airportList;
	
	//Array of airports (Which are the vertexes in the graph)
	private static String[] vertexes = {"Edinburgh", "Heathrow", "Dubai", "Sydney",  "Kuala Lumpur", "Frankfurt", "Auckland", "Rio de Janeiro", "New York", "Santiago"};
	
	//creates 20 edges to connect airports
	static DefaultWeightedEdge[] edges = new DefaultWeightedEdge[20];
	
	public static void main(String[] args){
		
		UserInteraction2 interact = new UserInteraction2();
		
		SimpleDirectedWeightedGraph<Airport[], DefaultWeightedEdge> flightsGraph = createWeightedGraph();
		
		
		interact.printFlights(flightsGraph);
		
		System.out.println();
		
		//Gets users input (start airport and destination airport) and stores in string array
		String[] airports = interact.getUserInput();
		
		
		HashMap<String, Airport[]> map = new HashMap<String, Airport[]>();
		
		//creates map so that the users inputed airport can obtain the object of the airport 
		for(int i=0; i < airportList.length; i++){
			
			map.put(vertexes[i], airportList[i]);		
			
		}
		
		//gets the object of the user input
		Airport[] airportOne = map.get(airports[0]);
		Airport[] airportTwo = map.get(airports[1]);
		
		
		//used to find the path between 2 airports
		DijkstraShortestPath<Airport[], DefaultWeightedEdge> path = new DijkstraShortestPath<Airport[], DefaultWeightedEdge>(flightsGraph, airportOne, airportTwo);
		
		//if a path can't be found will ask the user again for new inputs.
		while(DijkstraShortestPath.findPathBetween(flightsGraph, airportOne, airportTwo) == null){
			System.out.println("No route exists. Please try again.");
			String[] startAndEnd = interact.getUserInput();
			airportOne = map.get(startAndEnd[0]);
			airportTwo = map.get(startAndEnd[1]);
			
			path = new DijkstraShortestPath<Airport[], DefaultWeightedEdge>(flightsGraph, airportOne, airportTwo);
		
		}
		
		
		findFlightPath(flightsGraph, path, airportOne, airportTwo, airports);
			
	}
	
	public static SimpleDirectedWeightedGraph<Airport[], DefaultWeightedEdge> createWeightedGraph(){
		
		

		
		SimpleDirectedWeightedGraph<Airport[], DefaultWeightedEdge> flightsGraph = new SimpleDirectedWeightedGraph<>(DefaultWeightedEdge.class);
		
		
		
		//creates an array of the flight route arrays
		
		Airport[][] airports = getFlightRoutes();
		
		
		airportList = new Airport[airports.length][];
		
		//adds all airports to the list
		for(int i=0; i < airports.length; i++){
			
			airportList[i] = airports[i];
			
		}//end loop
		
		
		//lists the costs to add as the weight of the edges
		//there will be a much better way of doing this
		int[] costs = {80, 130, 570, 170, 190, 150, 90, 120, 430, 320};
		
		//used to connect vertexes, 0 (index 0) and 1 (index 1) are connected then 1 (index 1) and 0 (index 0) 
		//and then 1 (index 2) and 2 (index 3)and then 2 (index 3) and 1 (index 2) etc...
		//again quite a hacky method and better will exist
		int[] vertexindex = {0, 1, 1, 2, 1, 3, 2, 4, 2, 0, 4, 3, 0, 5,3, 6, 7, 8, 8, 9};	
		
       //adds airports to graph as vertexes
		for(int i=0; i < airportList.length; i++){
			
			flightsGraph.addVertex(airportList[i]);
		}//end loop
		
		
		for(int i=0; i < edges.length; i+=2){
			
			//each airport is connected both ways.
			
			Airport[] a1 = airportList[vertexindex[i]];
			Airport[] a2 = airportList[vertexindex[i+1]];
			
		
			
			//adds edges to graph connecting the airports (explained in comments above declaration of 'vertexindex'
			edges[i] = flightsGraph.addEdge(airportList[vertexindex[i]], airportList[vertexindex[i+1]]);
			edges[i+1] = flightsGraph.addEdge(airportList[vertexindex[i+1]], airportList[vertexindex[i]]);
			
			//sets weight of edges using cost
			flightsGraph.setEdgeWeight(edges[i], costs[i/2]);
        	flightsGraph.setEdgeWeight(edges[i+1], costs[i/2]);
			
		}//end loop
 
        return flightsGraph;
    }// close createWeightedGraph class
	
	
	private static void findFlightPath(SimpleDirectedWeightedGraph<Airport[], DefaultWeightedEdge> flightsGraph, DijkstraShortestPath<Airport[], DefaultWeightedEdge> path, Airport[] start, Airport[] end, String airports[]){

			
			System.out.println("Cheapest flight path is : ");
			
			java.util.Iterator<DefaultWeightedEdge> it = DijkstraShortestPath.findPathBetween(flightsGraph, start, end).iterator();
			java.util.Iterator<DefaultWeightedEdge> it2 = DijkstraShortestPath.findPathBetween(flightsGraph, start, end).iterator();
			
			
			ArrayList<Airport> listOfAirports = new ArrayList<Airport>();
			
			//iterator2 has to be 1 step ahead so there is access to the current airport (iterator 1) and the next airport (iterator 2)
			it2.next();
			
			//this is the airport to start from
			String startToCheck = airports[0];
			
			String lastAirportEndTime = "0";
			
			int noOfLoops = 0;
			
			while(it2.hasNext()){
				
				
				noOfLoops++;
				
				DefaultWeightedEdge next = it.next();
				DefaultWeightedEdge next2 = it2.next();
				
				
				Airport[] airportToCheck = flightsGraph.getEdgeSource(next);
				Airport[] nextAirport = flightsGraph.getEdgeSource(next2);
				
				//used to make list of times for a possible flight
				ArrayList<Airport> listOfTimes = new ArrayList<Airport>();
		
				//loops for the number of flights in current airport
				for(int i = 0; i < airportToCheck.length; i++){
					
					//if current startairport is equal to startToCheck & end airport is equal to nextAirport[0] & current starttime is equal to or more than 60 minutes than the last end time & current start time isn't more than 5 hours ahead of the last end time.
					if(airportToCheck[i].getStartAirport().equals(startToCheck) && airportToCheck[i].getEndAirport().equals(nextAirport[0].getStartAirport()) && timeSplit(airportToCheck[i].getStartTime()) >= timeSplit(lastAirportEndTime) + 60 && timeSplit(airportToCheck[i].getStartTime()) - timeSplit(lastAirportEndTime) <=300){
		
						//add each flightpath in the airport that passes the if statement into a list.
						listOfTimes.add(airportToCheck[i]);
					

					}//end if

				}//end loop
				
				if(listOfTimes.size() > 0){
					
					//returns the earliest possible flight that can be caught after last airport end time
					Airport min = checkTimes(listOfTimes, lastAirportEndTime);
					
					listOfAirports.add(min);
					
					//this becomes the new airport that the next flight must begin from
					startToCheck = min.getEndAirport();
						
				}//close if
			
				//if the size of the list is smaller than the number of loops then a flight could not be made within
				//an hour of the last flight landing and 5 hours later
				if(listOfAirports.size() < noOfLoops){
					System.out.println("This flight is not possible today due to times.");
					return;
				}//close if
				
				lastAirportEndTime = listOfAirports.get(noOfLoops - 1).getEndTime();

			}// close iterator while loop
			
			//if the size of the list is smaller than the number of loops then a flight could not be made within
			//an hour of the last flight landing and 5 hours later
			if(listOfAirports.size() < noOfLoops){
				System.out.println("This flight is not possible today due to times.");
				return;
			}
			
			
			Airport[] currentAirport = flightsGraph.getEdgeSource(it.next());
			
			noOfLoops++;
		
			//used to add the last flight path
			//hacky method but was required due to time issues
			//loops through flights at current airport
			for(int i = 0; i < currentAirport.length; i++){
				
				
				
				if(listOfAirports.isEmpty() && currentAirport[i].getEndAirport().equals(airports[1])){
			
					
					
					listOfAirports.add(currentAirport[i]);
					break;
					
				}else{
					
					if(currentAirport[i].getEndAirport().equals(airports[1])){
						
	
			
						//if current flight start time is equal to or equal to last airports end time + 1 hour
						if( timeSplit(currentAirport[i].getStartTime()) >= timeSplit(listOfAirports.get(listOfAirports.size() -1).getEndTime()) + 60){
							
							
							//if current flight start time - end time of last airport end time is less than 5 hours apart
							if((timeSplit(currentAirport[i].getStartTime()) - (timeSplit(listOfAirports.get(listOfAirports.size() -1).getEndTime())) <=300)){
								
								listOfAirports.add(currentAirport[i]);
						
								break;
							}
						
							
						}else{
							
							//if (twentyfourhoursinmins - last airport end time) + current start time is less or equal to 5 hours apart...
							if((TWENTYFOURHOURSINMINS - (timeSplit(listOfAirports.get(listOfAirports.size() -1).getEndTime()))) + timeSplit(currentAirport[i].getStartTime()) <= 300){
								
								listOfAirports.add(currentAirport[i]);
					
								break;
							}
							
						}
						
					}//close if 
				}//close else
				
				
			}//close for loop for adding last flight 
			
			//ensures flight route is possible
			if(listOfAirports.size() < noOfLoops){
				System.out.println("This flight is not possible today due to times.");
				return;
			}//close if
	
			
			
			double pathWeight = path.getPath().getWeight();
			
			//this will print the route information
			printPath(listOfAirports, pathWeight);
			
			
			
	}
	
	//adds flight time in air
	private static void addTimeInAir(String start, String end){
		
		//gets start time in mins
		int startMins = timeSplit(start);
	
	
	
		//gets the end time in minutes
		int endMins = timeSplit(end);

		//if ends mins is smaller than start mins you have to work out time until 24 hours and then add the remaining time until endtime
		if(endMins < startMins){
			int timeTill12 = TWENTYFOURHOURSINMINS - startMins;
			int after12 = endMins;
			int totalMins = timeTill12 + after12;
			
			timeInAir = (timeInAir) + totalMins;
			
		}else{
			timeInAir =  timeInAir + (endMins - startMins);
		}
		
		
		
		
	}
	
	//returns the minimum time so the user doesn't have to wait any longer than necessary
	private static Airport checkTimes(ArrayList<Airport> listOfTimes, String lastAirportTime){
		
		Airport minAirport = listOfTimes.get(0);
		
		for(int i=1; i < listOfTimes.size(); i++){
				
			
			if(timeSplit(listOfTimes.get(i).getStartTime()) < timeSplit(minAirport.getStartTime())){
				
				minAirport = listOfTimes.get(i);
			}
			
		}
		return minAirport;
		
	}
	
	public static Airport[][] getFlightRoutes(){
		
		MakeFlights flights = new MakeFlights();
		
		Airport[] edinburgh = flights.makeEdinburghFlightRoutes();
		Airport[] heathrow = flights.makeHeathrowFlightRoutes();
		Airport[] dubai = flights.makeDubaiFlightRoutes();
		Airport[] sydney = flights.makeSydneyFlightRoutes();
		Airport[] kuala = flights.makeKualaFlightRoutes();
		Airport[] frankfurt = flights.makeFrankfurtFlightRoutes();
		Airport[] auckland = flights.makeAucklandFlightRoutes();
		Airport[] rio = flights.makeRioFlightRoutes();
		Airport[] newYork = flights.makeNewYorkFlightRoutes();
		Airport[] santiago = flights.makeSantiagoFlightRoutes();
		
		Airport[][] airports = {edinburgh, heathrow, dubai, sydney, kuala, frankfurt, auckland, rio, newYork, santiago};
		
		return airports;
		
	}
	
	//returns time in minutes
	private static int timeSplit(String time){
		
		int timeInMins;
		
		//prevents program from crashing
		if(time.length() > 2){
			
		
		
		int	hour = Integer.parseInt(time.substring(0, time.length() - 2));
		int min = Integer.parseInt(time.substring(time.length() - 2, time.length()));
		
		timeInMins = (hour * 60) + min;
		
		}else{
			timeInMins = Integer.parseInt(time);
		}
		
		return timeInMins;
		
		
	}
	
	//calculates timeBetween flights
	private static void timeBetween(ArrayList<Airport> listOfAirports){
		
		for(int i=0; i < listOfAirports.size() - 1; i++){
			
			int endMins = timeSplit(listOfAirports.get(i).getEndTime());
			int startMins = timeSplit(listOfAirports.get(i+1).getStartTime());
			
			if(startMins < endMins){
				int timeTill12 = TWENTYFOURHOURSINMINS - endMins;
				int after12 = startMins;
				int total = timeTill12 + after12;
				
				
				totalTime = totalTime + total;
				
			}else{
				totalTime = totalTime + startMins - endMins;
			}
			
			
		}
		
	}
	
	//prints flightpaths
	private static void printPath(ArrayList<Airport> listOfAirports, double pathWeight){
		
		System.out.printf("%-4s %-15s %-4s %-6s %-15s %-4s \n","Leg", "Leave", "At", "On", "Arrive", "At");
		System.out.println();
		
		
		for(int i=0; i < listOfAirports.size(); i++){
			
			
			
			
			System.out.printf("%-4s %-15s %-4s %-6s %-15s %-4s \n", i+1,listOfAirports.get(i).getStartAirport(), listOfAirports.get(i).getStartTime(), listOfAirports.get(i).getFlightNo(), listOfAirports.get(i).getEndAirport(), listOfAirports.get(i).getEndTime());

			addTimeInAir(listOfAirports.get(i).getStartTime(), listOfAirports.get(i).getEndTime());
				
			
		}
		System.out.println();
	
		System.out.printf("%-20s £%.2f \n", "Cost of cheapest flight path is : ", pathWeight);
		timeBetween(listOfAirports);
		System.out.println("Total time of journey is : " + (totalTime + timeInAir));
		System.out.println("Total time in air is : " + timeInAir);
		
		
	}
	
	

}
	
