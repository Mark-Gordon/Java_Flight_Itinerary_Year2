package ImprovedFlights;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import org.jgrapht.graph.DefaultWeightedEdge;
import org.jgrapht.graph.SimpleDirectedWeightedGraph;

public class UserInteraction2 {
	
	ArrayList<String> airportList = new ArrayList<String>();
	
	//prints all possible flights
	public void printFlights(SimpleDirectedWeightedGraph<Airport[], DefaultWeightedEdge> flightsGraph){
		
		
		java.util.Iterator<DefaultWeightedEdge> it2 = flightsGraph.edgeSet().iterator();
		
		System.out.printf("%-15s %-4s %-6s %-15s %-4s %-5s\n", "Leave", "At", "On", "Arrive", "At", "Cost");
		
		Airport[][] airports = DirectFlights2.getFlightRoutes();
		
		for(int i=0; i < airports.length; i++){
			
			Airport[] currentAirport = airports[i];
			
			for(int y=0; y < currentAirport.length; y++){
				
				System.out.print(currentAirport[y].toString());
				
			}
			
			airportList.add(currentAirport[0].getStartAirport());
			
			
		}
		
	}
	
	public String[] getUserInput(){
		
		//used to hold users start and desired airport to arrive at
		String[] startAndEnd = new String[2];
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Please enter the start airport : ");
		
		
		startAndEnd[0] = input.nextLine();
		
		
		//keep asking for start airport until it is contained in the list
		while(!(airportList.contains(startAndEnd[0]))){
			System.out.println("'" + startAndEnd[0] + "' is not a valid aiport. Please try again : ");
			startAndEnd[0] = input.nextLine();
		}
		
	
		System.out.println("Please enter the destination airport : ");
		
		startAndEnd[1] = input.nextLine();
		
		
		//keeps asking user for the destination airport until it in in the list
		while(!(airportList.contains(startAndEnd[1]) && !(startAndEnd[0].equals(startAndEnd[1])))){
			System.out.println("'" + startAndEnd[1] + "' is not a valid aiport. Please try again : ");
			startAndEnd[1] = input.nextLine();
		}
		
		return startAndEnd;		
	}
	
	public void inputError(){
		
		System.out.println("One of the airports does not exist. Please try again.");
		
		getUserInput();
		
	}
	

}