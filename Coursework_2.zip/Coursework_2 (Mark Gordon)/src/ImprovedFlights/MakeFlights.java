package ImprovedFlights;

public class MakeFlights {
	
	public MakeFlights(){};
	
	
	public Airport[] makeEdinburghFlightRoutes(){
		
		Airport[] edinburghFlightList = new Airport[7];
		
		edinburghFlightList[0] = new Airport("Edinburgh", "0530", "FZ345", "Heathrow", "0640", 80);
		edinburghFlightList[1] = new Airport("Edinburgh", "1630", "FZ375", "Heathrow", "1740", 80);
		edinburghFlightList[2] = new Airport("Edinburgh", "0250", "ED185", "Dubai", "1005", 190);
		edinburghFlightList[3] = new Airport("Edinburgh", "0640", "ED050", "Dubai", "1405", 190);
		edinburghFlightList[4] = new Airport("Edinburgh", "1100", "ED240", "Dubai", "1815", 190);
		edinburghFlightList[5] = new Airport("Edinburgh", "1030", "ED140", "Dubai", "1745", 190);
		edinburghFlightList[6] = new Airport("Edinburgh", "1645", "ED710", "Frankfurt", "1930", 90);
		
		return edinburghFlightList;
	}
	
	public Airport[] makeHeathrowFlightRoutes(){
		
		Airport[] heathrowFlightList = new Airport[4];
		
		heathrowFlightList[0] = new Airport("Heathrow", "0430", "FD493", "Edinburgh", "0540", 80);
		heathrowFlightList[1] = new Airport("Heathrow", "0215", "FB385", "Dubai", "0950", 130);
		heathrowFlightList[2] = new Airport("Heathrow", "0510", "FB487", "Dubai", "1245", 130);
		heathrowFlightList[3] = new Airport("Heathrow", "0240", "HD870", "Sydney", "2345", 570);
		
		return heathrowFlightList;
	}
	
	public Airport[] makeDubaiFlightRoutes(){
		
		Airport[] dubaiFlightList = new Airport[8];
		
		dubaiFlightList[0] = new Airport("Dubai", "1210", "DB280", "Heathrow", "1940", 130);
		dubaiFlightList[1] = new Airport("Dubai", "1710", "DB785", "Heathrow", "2340", 130);
		dubaiFlightList[2] = new Airport("Dubai", "0315", "DB250", "Kuala Lumpur", "1005", 170);
		dubaiFlightList[3] = new Airport("Dubai", "1030", "DB240", "Kuala Lumpur", "1720", 170);
		dubaiFlightList[4] = new Airport("Dubai", "1420", "DB100", "Kuala Lumpur", "1945", 170);
		dubaiFlightList[5] = new Airport("Dubai", "1915", "DB210", "Kuala Lumpur", "2355", 170);
		dubaiFlightList[6] = new Airport("Dubai", "1040", "DB550", "Edinburgh", "1550", 190);
		dubaiFlightList[7] = new Airport("Dubai", "1940", "DB570", "Edinburgh", "2350", 190);
		
		return dubaiFlightList;
	}
	
	public Airport[] makeSydneyFlightRoutes(){
		
		Airport[] SydneyFlightList = new Airport[6];
		
		SydneyFlightList[0] = new Airport("Sydney", "0130", "SD185", "Heathrow", "2230", 570);
		SydneyFlightList[1] = new Airport("Sydney", "0040", "SY160", "Kuala Lumpur", "0745", 150);
		SydneyFlightList[2] = new Airport("Sydney", "0445", "SY340", "Kuala Lumpur", "1055", 150);
		SydneyFlightList[3] = new Airport("Sydney", "1540", "SY140", "Kuala Lumpur", "2145", 150);
		SydneyFlightList[4] = new Airport("Sydney", "0840", "SY750", "Auckland", "1130", 120);
		SydneyFlightList[5] = new Airport("Sydney", "2225", "SY450", "Auckland", "1155", 120);
		
		return SydneyFlightList;
	}
	
	public Airport[] makeKualaFlightRoutes(){
		
		Airport[] kualaFlightList = new Airport[7];
		
		kualaFlightList[0] = new Airport("Kuala Lumpur", "0240", "KU110", "Dubai", "0910", 170);
		kualaFlightList[1] = new Airport("Kuala Lumpur", "0930", "KU420", "Dubai", "1640", 170);
		kualaFlightList[2] = new Airport("Kuala Lumpur", "1205", "KU620", "Dubai", "1925", 170);
		kualaFlightList[3] = new Airport("Kuala Lumpur", "1410", "KU750", "Sydney", "1905", 150);
		kualaFlightList[4] = new Airport("Kuala Lumpur", "1725", "KU190", "Sydney", "2220", 150);
		kualaFlightList[5] = new Airport("Kuala Lumpur", "1840", "KU290", "Sydney", "2340", 150);
		kualaFlightList[6] = new Airport("Kuala Lumpur", "2345", "KU240", "Sydney", "0355", 150);
	
		return kualaFlightList;
	}
	
	public Airport[] makeFrankfurtFlightRoutes(){
		
		Airport[] frankfurtFlightList = new Airport[2];
		
		frankfurtFlightList[0] = new Airport("Frankfurt", "0315", "FR180", "Edinburgh", "0620", 90);
		frankfurtFlightList[1] = new Airport("Frankfurt", "1205", "FR480", "Edinburgh", "1510", 90);
	
		return frankfurtFlightList;
	}
	
	public Airport[] makeAucklandFlightRoutes(){
		
		Airport[] aucklandFlightList = new Airport[2];
		
		aucklandFlightList[0] = new Airport("Auckland", "0255", "AU480", "Sydney", "0355", 120);
		aucklandFlightList[1] = new Airport("Auckland", "1145", "AU080", "Sydney", "1445", 120);
		
	
		return aucklandFlightList;
	}
	
	public Airport[] makeRioFlightRoutes(){
		
		Airport[] rioFlightList = new Airport[2];
		
		rioFlightList[0] = new Airport("Rio de Janeiro", "0140", "RI530", "New York", "0930", 430);
		rioFlightList[1] = new Airport("Rio de Janeiro", "1040", "RI431", "New York", "2050", 430);
	
		return rioFlightList;
	}
	
	public Airport[] makeNewYorkFlightRoutes(){
		
		Airport[] newYorkFlightList = new Airport[4];
		
		newYorkFlightList[0] = new Airport("New York", "0430", "NY140", "Santiago", "1445", 320);
		newYorkFlightList[1] = new Airport("New York", "1230", "NY160", "Santiago", "1055", 320);
		newYorkFlightList[2] = new Airport("New York", "1255", "NY190", "Rio de Janeiro", "2305", 430);
		newYorkFlightList[3] = new Airport("New York", "1716", "NY230", "Rio de Janeiro", "0305", 430);
		
	
		return newYorkFlightList;
	}
	
	public Airport[] makeSantiagoFlightRoutes(){
		
		Airport[] santiagoFlightList = new Airport[2];
		
		santiagoFlightList[0] = new Airport("Santiago", "0135", "SA340", "New York", "1215", 320);
		santiagoFlightList[1] = new Airport("Santiago", "0945", "SA940", "New York", "2010", 320);
	
		
	
		return santiagoFlightList;
	}
	
	
	

}