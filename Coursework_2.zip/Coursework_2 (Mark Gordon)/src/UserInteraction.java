import java.awt.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import org.jgrapht.graph.DefaultWeightedEdge;
import org.jgrapht.graph.SimpleDirectedWeightedGraph;

public class UserInteraction {
	
	
	public void printFlights(SimpleDirectedWeightedGraph<String, DefaultWeightedEdge> stringGraph){
		
		
		java.util.Iterator<DefaultWeightedEdge> it2 = stringGraph.edgeSet().iterator();
		
		//prints out possible flight paths
		while(it2.hasNext()){
			
			DefaultWeightedEdge next = it2.next();
			
			System.out.printf("%-15s %-6s %-15s £%.2f \n",stringGraph.getEdgeSource(next), " <--> ", stringGraph.getEdgeTarget(next), stringGraph.getEdgeWeight(next));
			//System.out.println(stringGraph.getEdgeSource(next) + " <--> " + stringGraph.getEdgeTarget(next) + "  :  £" + stringGraph.getEdgeWeight(next));
			it2.next();
		}
		
	}
	
	public String[] getUserInput(){
		
		
		DirectFlights flights = new DirectFlights();
		
		String[] airportArray = flights.getVertexes();
		
		
		ArrayList<String> airports = new ArrayList<String>(Arrays.asList(airportArray));
		
		String[] startandEnd = new String[2];
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Please enter the start airport : ");
		
		
		startandEnd[0] = input.nextLine();
		
		//asks user for start airport until it exists in list
		while(!(airports.contains(startandEnd[0]))){
			System.out.println("'" + startandEnd[0] + "' is not a valid aiport. Please try again : ");
			startandEnd[0] = input.nextLine();
		}
		
	
		System.out.println("Please enter the destination airport : ");
		
		startandEnd[1] = input.nextLine();
		
		
		//asks user for destination airport until it is in the list and is not same as start airport
		while(!(airports.contains(startandEnd[1]) && !(startandEnd[0].equals(startandEnd[1])))){
			System.out.println("'" + startandEnd[1] + "' is not a valid aiport. Please try again : ");
			startandEnd[1] = input.nextLine();
		}
		
		
		return startandEnd;	
		
	}
	
	public void inputError(){
		
		System.out.println("One of the airports does not exist. Please try again.");
		
		getUserInput();
		
	}
	

}
